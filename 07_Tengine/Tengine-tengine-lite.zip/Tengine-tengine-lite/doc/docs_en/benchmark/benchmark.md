# Performance data

The data has a slight lag, and the actual measurement shall prevail.

## ARM test environment

### ARM test environment

## GPU test environment

### GPU test environment

## NPU test environment

### NPU test environment
