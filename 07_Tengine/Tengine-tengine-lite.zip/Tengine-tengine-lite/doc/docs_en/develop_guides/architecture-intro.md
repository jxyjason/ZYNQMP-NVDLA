# Architectural details

## Basic Principles of Design

## Introduction to important modules

## Extend the hardware backend