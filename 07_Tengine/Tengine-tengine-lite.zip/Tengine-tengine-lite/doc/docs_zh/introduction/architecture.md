# 架构设计

Tengine 架构如下图

![Tengine 架构图](../images/architecture.png)
