# Road map

每个季度更新一次 Flag。

## 2021Q2

- [x] refactor the framework code
- [x] refactor the NPU plugin code
- [x] support VS2017 compile
- [ ] support macOS compile
- [x] support the mode type of PaddlePaddle
- [ ] add more examples with NPU platform 
- [ ] fix the Float32 bugs of Vulkan
