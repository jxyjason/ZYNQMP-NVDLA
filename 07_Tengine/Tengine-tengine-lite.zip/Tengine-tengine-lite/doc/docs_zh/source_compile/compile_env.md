# 源码编译环境准备

## 依赖工具安装

编译 Tengine 依赖 `git, g++, cmake, make` 等以下基本工具，如果没有安装，

- Ubuntu18.04 系统命令如下：

  ```bash
  sudo apt-get install cmake make g++ git
  ```

- Fedora28 系统命令如下：

  ```bash
  sudo dnf install cmake make g++ git
  ```
  